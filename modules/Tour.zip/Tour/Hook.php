<?php


namespace Modules\Tour;


class Hook
{
    const FORM_AFTER_MAX_PEOPLE = 'tour_form_after_max_people';

    const AFTER_SAVING = 'tour_after_saving';
}
